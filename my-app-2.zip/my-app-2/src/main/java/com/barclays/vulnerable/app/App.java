package com.barclays.vulnerable.app;

//import java.security.Security;
//add the provider package
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jasypt.util.text.BasicTextEncryptor;
import org.apache.commons.io.FileSystemUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.LineIterator;
import org.apache.commons.io.IOCase;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 * Hello world!
 *
 */
public class App 
{
	/* Get actual class name to be printed on */
	private static final Logger logger = LogManager.getLogger("HelloWorld");
	
    public static void main( String[] args ) {
		BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
		textEncryptor.setPassword("Mirek");
		System.out.println(textEncryptor.encrypt("ABCDEF"));
		logger.error("Hello this is a debug message" + "\n\r11:39:01.873 [main] ERROR HelloWorld ");
		logger.info("Hello this is an info message");
		//add at runtime the Bouncy Castle Provider
		//the provider is available only for this application
    new BouncyCastleProvider();
        System.out.println( "Hello World!" );
		
		try {
			FilenameUtils.getFullPath("dfdfdf");
			DiskFileItemFactory factory = new DiskFileItemFactory();
		} finally {
			
		}
    }
}
