TLD file is generated inside META-INF after compilation.
If META-INF is empty, Maven will not copy it to the "target/classes" folder.
Please do not remove META-INF, or this file.